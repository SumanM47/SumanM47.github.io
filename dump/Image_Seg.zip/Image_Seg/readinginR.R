library(png)
img <- readPNG("kodima03.png")